from django.apps import AppConfig


class EjemploappConfig(AppConfig):
    name = 'ejemploapp'
