from django.urls import path
from .views import*


urlpatterns = [
  
    path('', saludar),
    path('cocinero/nuevo', nuevococinero),
    path('pedido/', consultarpedido),
    path('consultarreserva/', consultarpedido),
    path('pedirplato/', pedirplato),
    path('verificarplato/', verificarplato),
    path('abros/', abros),
]